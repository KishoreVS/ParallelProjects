import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/Entity/Account';
import { Transactions } from 'src/app/Entity/Transactions';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  isLogin:boolean=true;
  accounts:Account[]=[];
  createdTransaction:Transactions;
  router:Router;

  service:BankService;
  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  deposit(data:any){
    let transFrom=data.accNum;
    let accBal=data.accBal;
    var transType:string;
    transType="Deposit";
    let transId=Math.floor(Math.random() * 10) + 2549 ;
    this.service.deposit(transFrom,accBal);
    this.createdTransaction=new Transactions(transId,data.accNum,0,data.accBal,transType);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['home']);
  }


  ngOnInit() {
    this.accounts=this.service.getAccounts();
  }

}
