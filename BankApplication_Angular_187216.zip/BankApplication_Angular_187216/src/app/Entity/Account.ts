export class Account
{
    accNum:number;
    accName:string;
    accPh:number;
    accPass:string;
    accAdd:string;
    accBal:number;

    constructor(accNum:number,accName:string,accPh:number,accPass:string,accAdd:string,accBal:number)
    {
        this.accNum=accNum;
        this.accName=accName;
        this.accPh=accPh;
        this.accPass=accPass;
        this.accAdd=accAdd;
        this.accBal=accBal;
    }

}