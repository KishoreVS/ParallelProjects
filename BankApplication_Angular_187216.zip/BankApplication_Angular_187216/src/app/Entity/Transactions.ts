export class Transactions
{
    transId:number;
    transFrom:number;
    transTo:number;
    transAmount:number;
    transType:string;

    constructor(transId:number,transFrom:number,transTo:number, transAmount:number,transType:string)
    {
        this.transId=transId;
        this.transFrom=transFrom;
        this.transTo=transTo;
        this.transAmount=transAmount;
        this.transType=transType;
    }
}