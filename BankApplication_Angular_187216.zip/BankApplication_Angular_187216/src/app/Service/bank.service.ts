import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Transactions } from '../Entity/Transactions';
import { Account } from '../Entity/Account';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  http:HttpClient;
  isLogin:boolean=true;
  accounts:Account[]=[];
  transactions:Transactions[]=[];
  tempTrans:Transactions[]=[];
  fetched:boolean=false;
  fetched1:boolean=false;
  loginAccount:number=0;

  constructor(http:HttpClient) {
    this.http=http;
    this.fetchAccounts();
    this.fetchTransactions();
   }
  fetchAccounts()
  {
    this.http.get('./assets/Account.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Account(o.accNum,o.accName,o.accPh,o.accPass,o.accAdd,o.accBal);
      this.accounts.push(e);
    }
  }
  fetchTransactions()
  {
    {
      this.http.get('./assets/Transactions.json')
      .subscribe
      (
        data=>
        {
          if(!this.fetched1)
          {
            this.convertTrans(data);
            this.fetched1=true;
          }
        }
      );
    }
  }
  convertTrans(dataT:any)
  {
    for(let o of dataT)
    {
      let e=new Transactions(o.transId,o.transFrom,o.transTo,o.transAmount,o.transType);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }
  
  getAccounts():Account[]
  {
    return this.accounts;
  }

  getTransactions():Transactions[]
  {
    return this.transactions;
  }

  showTransactions(accNum:number):Transactions[]{
    this.tempTrans=[];
    for(let i=0;i<this.transactions.length;i++)
    {
      let e=this.transactions[i];
      if(accNum==e.transFrom)
      {
        this.tempTrans.push(e);
      }
    }
    return this.tempTrans;
  }

  add(e:Account){
    this.accounts.push(e);
    var myJSON = JSON.stringify(this.accounts);
  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:Account):number{
    let accNum = data.accNum; 
    for(let i=0;i<this.accounts.length;i++)
      {
        if(accNum == this.accounts[i].accNum)
        {
          let accBal=this.accounts[i].accBal;
          return accBal;
        }
        else
        {
          continue;
        }
      }
      alert("Account No not found!")
  }

  deposit(accNum1:number,accBal:number){

    for(let i=0;i<this.accounts.length;i++)
    {
      if(this.loginAccount == this.accounts[i].accNum)
      {
        let depositeB:number=this.accounts[i].accBal;
        this.accounts[i].accBal=parseInt(depositeB.toString()) + parseInt(accBal.toString());
        alert("Amount deposited \nUpdated balance : "+this.accounts[i].accBal);
        return true;
      }else if(accNum1 == this.accounts[i].accNum){
        let depositeB:number=this.accounts[i].accBal;
        this.accounts[i].accBal=parseInt(depositeB.toString()) + parseInt(accBal.toString());
        alert("Amount deposited \nUpdated balance : "+this.accounts[i].accBal);
        return true;
      }else{
        continue;
      }
    }
  }
  
  withdraw(accNum1:number,accBal:number){
    for(let i=0;i<this.accounts.length;i++)
    {
      if(this.loginAccount == this.accounts[i].accNum)
      {
        let depositeB:number=this.accounts[i].accBal;
        this.accounts[i].accBal=parseInt(depositeB.toString()) - parseInt(accBal.toString());
        alert("Amount Withdrawn \nUpdated balance : "+this.accounts[i].accBal);
        return true;
      }else if(accNum1 == this.accounts[i].accNum){
        let depositeB:number=this.accounts[i].accBal;
        this.accounts[i].accBal=parseInt(depositeB.toString()) - parseInt(accBal.toString());
        alert("Amount Withdrawn \nUpdated balance : "+this.accounts[i].accBal);
        return true;
      }else{
        continue;
      }
    }
  }

  login(data:Account):boolean
  {
    let accNum=data.accNum;
    let accPass=data.accPass;

    for(let a of this.accounts)
    {
      console.log(this.accounts)
      if(accNum == a.accNum && accPass == a.accPass)
      {
       
        alert("Login Successful")
        this.isLogin=!this.isLogin;
        return true;
      }
      else
      {
        continue;
      }
      
    }
    return false;
  }
 
}
