import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';
import { Account } from 'src/app/Entity/Account';

@Component({
  selector: 'balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.css']
})
export class BalanceComponent implements OnInit {

  isLogin:boolean=true;
  accounts:Account[]=[];
  bal:number;
  router:Router;
  isShowBalance:boolean=true;
  service:BankService;

  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  showBalance(data:any){
      var bal = this.service.showBalance(data);
      bal.subscribe( (data)=>{
      alert("Current balance : "+data)
      this.isShowBalance=!this.isShowBalance;
      this.router.navigate(['home']);
    })
  
  }
          
  ngOnInit() {
    this.service.fetchAccounts();
    this.accounts=this.service.getAccounts();
  }

}
