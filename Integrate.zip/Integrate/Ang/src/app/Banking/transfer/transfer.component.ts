import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/Entity/Transactions';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transactions;
  router:Router;
  service:BankService;
  
  constructor(service:BankService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  fundTransfer(data:any){
    let accNum=data.accNum;
    let accNum1=data.accNum1;
    let accBal=data.accBal;

    var trans = this.service.transfer(accNum,accBal,accNum1);
    trans.subscribe((data)=>{
      alert("Updated Balance : "+data)
    })
    this.router.navigate(['home']);
  }

  ngOnInit() {
  }

}
