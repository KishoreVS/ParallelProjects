export class Account
{
    accNo:number;
    name:string;
    mobNo:number;
    pwd:string;
    address:string;
    bal:number;

    constructor(accNo:number,name:string,mobNo:number,pwd:string,address:string,bal:number)
    {
        this.accNo=accNo;
        this.name=name;
        this.mobNo=mobNo;
        this.pwd=pwd;
        this.address=address;
        this.bal=bal;
    }

}