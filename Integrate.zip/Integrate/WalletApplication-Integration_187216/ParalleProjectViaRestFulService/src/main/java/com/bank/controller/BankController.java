package com.bank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bank.entities.BankEntity;
import com.bank.entities.TransactionEntity;
import com.bank.exception.BankException;
import com.bank.service.BankService;

@RestController
@RequestMapping("/BankApplication")
@CrossOrigin(origins="http://localhost:4200")
public class BankController {
	@Autowired
	BankService bankService;

	
	@PostMapping("/CreateAccount")
	@CrossOrigin(origins="http://localhost:4200")
	public BankEntity createAccount(@RequestBody BankEntity bank) throws BankException {
		return bankService.createAccount(bank);
	}

	@GetMapping("/ShowDetails/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public BankEntity accountsDetails(@PathVariable Long accNo) throws BankException {
		return bankService.accountsDetails(accNo);
	}
	
	@GetMapping("/getAllAccounts")
	@CrossOrigin(origins="http://localhost:4200")
	public List<BankEntity> getAllAccounts(){
		return bankService.getAllAccounts();
	}

	@GetMapping("/ShowBalance/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double showBalance(@PathVariable Long accNo) throws BankException {
		return bankService.showBalance(accNo);

	}

	@PutMapping("/DepositAmount/{accNo}/{amt}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double deposit(@PathVariable Long accNo, @PathVariable Double amt) throws BankException {
		return bankService.deposit(accNo, amt);
	}

	@PutMapping("/WithdrawAmount/{accNo}/{amt}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double withdraw(@PathVariable Long accNo, @PathVariable Double amt) throws BankException {
		return bankService.withdraw(accNo, amt);
	}

	@PutMapping("/FundTransfer/{sender}/{amount}/{reciver}")
	@CrossOrigin(origins="http://localhost:4200")
	public Double fundTransfer(@PathVariable Long sender, @PathVariable Double amount,
			@PathVariable Long reciver) throws BankException {
		return bankService.fundTransfer(sender, amount, reciver);

	}

	@GetMapping("/MiniStatement/{accNo}")
	@CrossOrigin(origins="http://localhost:4200")
	public List<TransactionEntity> printTransaction(@PathVariable Long accNo) {
		return bankService.printTransaction(accNo);
	}

}
