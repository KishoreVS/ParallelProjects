package com.wallet.dao;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Test;

import com.wallet.entities.BankEntity;

public class BankJunit {
	EntityManager con;
	ConnectionDatabase cd = new ConnectionDatabase();

	// Hashmap which is storing all account holders information
	BankEntity bb1; // object of Bankbean class

	@Test // getting Balance of account holder by reference to their accno
	public void getBalance() {

		con = cd.getConnection();
		con.getTransaction().begin();
		BankEntity emp1 = (BankEntity) con.find(BankEntity.class, new Long(10007336));
		con.getTransaction().commit();
		long observed = emp1.getBalance();
		long expected = 1000;
		Assert.assertEquals(expected, observed);

	}

	@Test
	public void getInfo() {
		// TODO Auto-generated method stub
		con = cd.getConnection();
		con.getTransaction().begin();
		BankEntity emp1 = (BankEntity) con.find(BankEntity.class, new Long(10007336));
		con.getTransaction().commit();
		long observed = emp1.getBalance();
		long expected = 1000;
		Assert.assertEquals(expected, observed);
	}

}