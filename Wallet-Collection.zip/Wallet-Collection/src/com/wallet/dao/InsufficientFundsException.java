package com.wallet.dao;

public class InsufficientFundsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFundsException(final String msg) {
		super(msg);
	}

	public InsufficientFundsException(final String msg, final Throwable exc) {
		super(msg, exc);
	}

}
