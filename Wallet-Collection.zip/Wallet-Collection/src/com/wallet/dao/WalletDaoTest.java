package com.wallet.dao;

public class WalletDaoTest {

}
