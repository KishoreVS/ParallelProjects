package com.wallet.service;

import java.util.ArrayList;
import java.util.Scanner;

import com.wallet.bean.Transactions;
import com.wallet.bean.WalletBean;
import com.wallet.dao.WalletDao;

public class WalletService implements WalletServiceI {

	WalletDao wd = new WalletDao();

	@Override
	public WalletBean createAccount(WalletBean wbCreateAccount) {
		return wd.createAccount(wbCreateAccount);
	}

	@Override
	public double balanceEnquiry(String accNo) {
		return wd.balanceEnquiry(accNo);
	}

	@Override
	public double deposit(String accNo, double dep) {
		return wd.deposit(accNo, dep);
	}

	@Override
	public double withdrawal(String accNo, double wAmt) {
		return wd.withdrawal(accNo, wAmt);
	}

	@Override
	public double transfer(String accNo, String ran, double tAmt) {
		return wd.transfer(accNo, ran, tAmt);
	}

	@Override
	public ArrayList<Transactions> miniStatement(String accNo) {
		return wd.miniStatement(accNo);

	}

	public String nameCheck(String name) {
		if (name.matches("([A-Za-zA-Z])*"))
			return name;

		else
			System.out.println("Name should only have alphabets.");
		System.out.println("Enter again: ");
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		return name = s.next();
	}

	// METHOD TO CHECK THE LENGTH OF MOBILE NUMBER
	public String mobCheck(String num) {
		while (true) {
			if (String.valueOf(num).length() == 10) {
				return num;

			}

			else {
				System.out.println("Enter valid 10 digit mobile number.");
				Scanner s = new Scanner(System.in);
				num = s.next();
				s.close();
			}
		}
	}
}