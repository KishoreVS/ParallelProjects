package com.bank.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bank.entities.Bank;
import com.bank.entities.Transaction;

@Repository("bankDAO")
@Transactional
public class BankDAO implements BankDaoI {


	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	Random rand = new Random();
	
	@Override
	public boolean createAccount(Bank bank) {
		entityManager.persist(bank);
		return true;

	}

	@Override
	public int showBalance(long accountNo) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		balance = bank.getBalance();
		return balance;
	}

	@Override
	public int depositBalance(long accountNo, int deposit) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		int bal = bank.getBalance();
		int bal1 = bal + deposit;
		bank.setBalance(bal1);
		Transaction tran = new Transaction();
		tran.setAmount(deposit);
		tran.setTransactionId(rand.nextInt(100000));
		tran.setTransactionType("deposit");
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);

		return bal1;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance = 0;
		Bank bank = entityManager.find(Bank.class, accountNo);
		int bal = bank.getBalance();
		int bal1 = bal - withdraw;
		bank.setBalance(bal1);
		
		Transaction tran = new Transaction();
		tran.setAmount(withdraw);
		tran.setTransactionId(rand.nextInt(100000));
		tran.setTransactionType("withdraw");
		tran.setBank(bank);
		entityManager.persist(tran);
		entityManager.merge(bank);

		return bal1;

	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		Bank bank = entityManager.find(Bank.class, accountNo);
		Bank bank1 = entityManager.find(Bank.class, accno);
		if (bank.getBalance() <= amount) {
			b = false;
		} else {
			int bal = bank.getBalance();
			int bal1 = bank1.getBalance();
			int bal2 = bal1 + amount;
			int bal3 = bal - amount;
			
			bank1.setBalance(bal2);
			Transaction tran = new Transaction();
			tran.setAmount(amount);
			tran.setTransactionId(rand.nextInt(100000));
			tran.setTransactionType("fund transfer");
			tran.setBank(bank1);
			tran.setFromAccount(accno);
			entityManager.persist(tran);
			
			bank.setBalance(bal3);
			Transaction tran1 = new Transaction();
			tran1.setAmount(amount);
			tran1.setTransactionId(rand.nextInt(100000));
			tran1.setTransactionType("fund transfer");
			tran1.setBank(bank);
			tran.setFromAccount(accountNo);
			entityManager.persist(tran1);
			b = true;
		}
		return b;
	}

	@Override
	public boolean validateAccount(long accountNo, String password) {
		boolean b = false;
		
		Bank bank1 = entityManager.find(Bank.class, accountNo);
		if(bank1==null)
		{
			b=false;
		}
		else
		{
	   String pass = bank1.getPassword();
		//System.out.println(pass);
		if (password.equals(pass)) {
			b = true;
		}
		else
		{
			b =false;
		}
		
		}
		return b;
	}

	@Override
	public List<Transaction> getTransactions(long accountNo) {
		Bank bank = entityManager.find(Bank.class, accountNo);
		TypedQuery<Transaction> query = entityManager.createQuery("Select t from Transaction as t where t.bank=:bank",
				Transaction.class);
		query.setParameter("bank", bank);
		List<Transaction> trans = query.getResultList();
		return trans;
	}

	
}